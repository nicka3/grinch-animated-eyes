// STEP 3 - Grinch animated eyes (wiring is in include/lgfx_config.h).
// Hold BOOT at power-up (or press it any time) for the calibration crosshairs.
// Adjust EYE_L_* / EYE_R_* until each crosshair sits centred in its eye hole.

// SOUND (2026-11-15): radar sees someone ARRIVE -> play the next MP3 from the SD card's
// "mp3" folder (0001.mp3, 0002.mp3 ...), wrapping back to 0001 after the last one.
// The track number is remembered across power-offs. No button yet: motion mode is always on.
// Test without the radar: open the Serial Monitor and type  p  (play next)  or  +  /  -  (volume).

#include <Arduino.h>
#include <Preferences.h>
#include "lgfx_config.h"

// ---------------- sound settings ----------------
static const int PIN_DF_TX    = 17;       // ESP32 -> 510 ohm -> DFPlayer RX
static const int PIN_DF_RX    = 18;       // ESP32 <- DFPlayer TX
static const int PIN_RADAR    = 4;        // LD2410C OUT (HIGH = someone there)
static const int PIN_GBUTTON  = 5;        // green button switch (one blue wire; the other blue wire -> GND)
static const int PIN_GLED     = 6;        // green ring LED (HIGH = on; needs a transistor + 5 V to light)
static int       VOLUME       = 18;  // first-power-up volume; after that the button's choice is remembered. 0..30 (30 distorts; boost quiet MP3s in Audacity instead)
static const uint32_t COOLDOWN_MS  = 1500;    // short pause after a sound ends; then any motion plays the next one
static const uint8_t  MAX_IN_A_ROW = 1;      // then the radar must see "nobody" before the next sound (stops endless loops)
static const uint32_t MAX_SOUND_MS = 120000;  // safety: treat a sound as finished after 2 min
// ------------------------------------------------

// ---------------- user settings ----------------
static const int PIN_BUTTON = 0;          // BOOT button on the DevKitC-1
static const int SCREEN_ROTATION = 3;     // 3 = upright with header pins on the right (screen test 2026-11-11)
static const uint8_t BACKLIGHT = 200;     // 0..255

// Eye centres in screen pixels (landscape 320x240, x right, y down, seen from the front).
// From the Blender model: left-eye tunnel at -17.5/+8.0 mm, right at +15.5/+4.0 mm from the
// nominal active-area centre, 0.18 mm per pixel. Fine-tune with calibration mode.
// 2026-11-11 fit test: both eyes sat left of the holes -> L +9 px, R +13 px (R is now at the
// right-hand limit: 259 + 61 = 320, the edge of the active area).
static int EYE_L_X = 72,  EYE_L_Y = 79;   // figure's right eye = viewer's LEFT
static int EYE_R_X = 259, EYE_R_Y = 93;   // viewer's RIGHT
static const float MM_PER_PX = 0.18f;

// Eye artwork (pixels). Face opening is ~22 mm (r = 61 px); tunnel at screen ~28 mm (r = 78 px).
static const int   EYE_SPRITE = 160;      // square sprite per eye
static const int   IRIS_R  = 42;          // 15 mm iris
static const int   PUPIL_R = 29;          // 10.4 mm pupil
static const int   GLINT_R = 10;
static const float GAZE_SCALE = 1.6f;     // multiplies gaze (mm) -> more lively movement
static const float GAZE_MAX_MM = 3.2f;    // keep iris inside the 22 mm opening

static const uint8_t SCLERA[3] = {236, 236, 226};
static const uint8_t IRIS_O[3] = { 40, 110,  40};   // iris outer ring
static const uint8_t IRIS_I[3] = { 95, 175,  70};   // iris inner
static const uint8_t PUPIL[3]  = { 12,  12,  12};
static const uint8_t LID[3]    = {146, 188,  52};   // Grinch skin (sampled from the sculpt)
static const uint8_t LID_EDGE[3] = { 70, 110,  20};
// Angry look while a sound plays (2026-11-16): a slanted upper lid, lower toward the nose,
// plus a slight squint from below. Pixels down from the top/bottom of the 22 mm face opening.
// No lids at all while he's quiet. (2026-11-16 v2: steeper - outer 12->2, inner 40->62)
static const int   ANGRY_OUTER_PX = 2;    // upper lid at the outer corner (stays up)
static const int   ANGRY_INNER_PX = 62;   // upper lid at the inner corner (by the nose) - raise for angrier
static const int   ANGRY_LOWER_PX = 10;   // lower lid squint
static const float ANGRY_IN_MS    = 220;  // ease in when a sound starts
static const float ANGRY_OUT_MS   = 120;  // snap back to calm when it ends
static const int   OPEN_R = 61;           // face opening radius (px)
// ------------------------------------------------


static LGFX tft;
static LGFX_Sprite spr(&tft);

static inline uint16_t col(const uint8_t c[3]) { return tft.color565(c[0], c[1], c[2]); }

// ---------------- animation state ----------------
struct Gaze { float x, y; };                  // mm, +x viewer's right, +y up
static Gaze gazeFrom{0, 0}, gazeTo{0, 0}, gazeNow{0, 0};
static uint32_t sacStart = 0, sacDur = 40, nextSaccade = 0;
static uint32_t blinkStart = 0, blinkClose = 35, blinkHold = 17, blinkOpen = 75, nextBlink = 2500;
static bool blinking = false, doubleBlinkPending = false, quickNext = false;
static bool calibration = false;

static float easeOut(float t) { t = constrain(t, 0.f, 1.f); return 1 - (1 - t) * (1 - t) * (1 - t); }

static void planSaccade(uint32_t now) {
  gazeFrom = gazeNow;
  float r = random(1000) / 1000.f;
  if (r < 0.25f) {                       // small corrective flick near current point
    gazeTo.x = gazeNow.x + (random(-30, 31) / 100.f);
    gazeTo.y = gazeNow.y + (random(-30, 31) / 100.f);
  } else if (r < 0.40f) {                // back to centre
    gazeTo = {0, 0};
  } else {                               // new target (same ranges as the Blender preview)
    gazeTo.x = random(-200, 201) / 100.f;
    gazeTo.y = random(-110, 121) / 100.f;
  }
  float d = hypotf(gazeTo.x - gazeFrom.x, gazeTo.y - gazeFrom.y);
  sacDur = 33 + (uint32_t)(d * 9);       // 2-3 frames at 60 fps, a bit longer for big jumps
  sacStart = now;
  nextSaccade = now + sacDur + (r < 0.25f ? random(150, 450) : random(400, 2600));
}

static void planBlink(uint32_t now, bool quick) {
  blinking = true; blinkStart = now;
  blinkClose = random(30, 52); blinkHold = 17; blinkOpen = random(65, 90);
  if (!quick && random(100) < 18) doubleBlinkPending = true;
}

// 0 = open, 1 = closed
static float blinkAmount(uint32_t now) {
  if (!blinking) return 0;
  uint32_t t = now - blinkStart;
  if (t < blinkClose) return easeOut((float)t / blinkClose);
  t -= blinkClose;
  if (t < blinkHold) return 1;
  t -= blinkHold;
  if (t < blinkOpen) return 1 - easeOut((float)t / blinkOpen);
  blinking = false;
  if (doubleBlinkPending) { doubleBlinkPending = false; quickNext = true; nextBlink = now + random(90, 160); }
  else nextBlink = now + random(1800, 6500);
  return 0;
}

// ---------------- sound: DFPlayer Mini over Serial1 ----------------
static Preferences prefs;
static bool     dfReady = false, playing = false, retriedWrap = false;
static uint16_t trackCount = 0;           // files on the card (0 = unknown)
static uint16_t nextTrack = 1, curTrack = 0;
static uint32_t playStart = 0, quietUntil = 0;
static bool     radarLast = false, radarArmed = false;
static bool     motionOn = true;          // green button toggles this (saved)
static uint32_t radarChange = 0;

static void dfSend(uint8_t cmd, uint16_t param) {
  uint8_t f[10] = {0x7E, 0xFF, 0x06, cmd, 0x00, (uint8_t)(param >> 8), (uint8_t)param, 0, 0, 0xEF};
  uint16_t sum = 0;
  for (int i = 1; i < 7; i++) sum += f[i];
  sum = 0 - sum;
  f[7] = sum >> 8; f[8] = sum & 0xFF;
  Serial1.write(f, 10);
}

static void soundFinished(uint32_t now, const char *why) {
  if (!playing) return;
  playing = false;
  quietUntil = now + COOLDOWN_MS;
  Serial.printf("[sound] finished (%s). Quiet for %lu s\n", why, COOLDOWN_MS / 1000);
}

static void playNext(uint32_t now) {
  if (trackCount && nextTrack > trackCount) nextTrack = 1;
  curTrack = nextTrack;
  dfSend(0x12, curTrack);                 // play mp3\NNNN*.mp3
  playing = true; playStart = now;
  Serial.printf("[sound] playing mp3\\%04u\n", curTrack);
  nextTrack = curTrack + 1;
  if (trackCount && nextTrack > trackCount) nextTrack = 1;
  prefs.putUShort("next", nextTrack);
  // the Grinch looks straight at whoever arrived and blinks
  gazeFrom = gazeNow; gazeTo = {0, 0}; sacStart = now; sacDur = 60; nextSaccade = now + 2500;
  if (!blinking) planBlink(now, true);
}

static void dfHandle(uint8_t cmd, uint16_t p, uint32_t now) {
  switch (cmd) {
    case 0x3F:                            // module finished starting up
      Serial.printf("[df] ready (0x%02X)\n", p);
      break;
    case 0x48: case 0x47: case 0x4E:      // file count answer
      trackCount = p;
      Serial.printf("[df] %u sound file(s) on the card\n", trackCount);
      break;
    case 0x3D:                            // track finished (clones may send it twice)
      soundFinished(now, "end of track");
      break;
    case 0x40:                            // error
      Serial.printf("[df] error %u%s\n", p, p == 6 ? " (file not found)" : p == 1 ? " (busy / no card)" : "");
      if (p == 6 && playing && curTrack != 1 && !retriedWrap) {   // ran past the last file: wrap to 0001
        retriedWrap = true; trackCount = curTrack - 1; nextTrack = 1;
        playing = false; playNext(now);
      } else {
        playing = false;
      }
      break;
    case 0x42: {                          // status answer: low byte 0 = stopped, 1 = playing
      static uint8_t stoppedTwice = 0;    // need two "stopped" answers in a row, to be safe
      stoppedTwice = (playing && (p & 0xFF) == 0) ? stoppedTwice + 1 : 0;
      if (stoppedTwice >= 2) { stoppedTwice = 0; soundFinished(now, "player says stopped"); }
      break;
    }
    case 0x41: break;                     // ACK
    default:
      Serial.printf("[df] msg 0x%02X %u\n", cmd, p);
  }
}

static void dfPoll(uint32_t now) {
  static uint8_t buf[10]; static int n = 0;
  while (Serial1.available()) {
    uint8_t b = Serial1.read();
    if (n == 0 && b != 0x7E) continue;
    buf[n++] = b;
    if (n == 10) {
      if (buf[9] == 0xEF) dfHandle(buf[3], (buf[5] << 8) | buf[6], now);
      n = 0;
    }
  }
  if (!dfReady && now > 2500) {           // give the module time to read the card
    dfReady = true;
    dfSend(0x06, VOLUME);  delay(60);
    dfSend(0x48, 0);                      // how many files are on the card?
    Serial.printf("[df] volume %d, asking for file count\n", VOLUME);
  }
  // backup in case the "track finished" message is missed (some clones): ask once a second
  static uint32_t lastAsk = 0;
  // 2026-11-17: OFF - this module reports "end of track" fine, and asking during playback can make clones stutter
  if (false && playing && now - playStart > 1500 && now - lastAsk > 1000) { lastAsk = now; dfSend(0x42, 0); }
  if (playing && now - playStart > MAX_SOUND_MS) soundFinished(now, "timeout");
}

static void radarPoll(uint32_t now) {
  bool r = digitalRead(PIN_RADAR);
  if (r != radarLast) { radarLast = r; radarChange = now; return; }
  if (now - radarChange < 150) return;    // ignore flicker shorter than 0.15 s
  static int reported = -1;               // log every steady change so the radar can be tested
  if (reported != (int)r) {
    reported = r;
    Serial.printf("[radar] %s  (%lu s since power-up)\n", r ? "SEES SOMEONE" : "nobody", now / 1000);
  }
  static uint8_t inARow = 0;              // sounds played while the radar never went quiet
  if (!r) { radarArmed = true; inARow = 0; return; }  // nobody there
  // Motion plays the next sound as soon as the last one is done or stopped (+ a short pause).
  // 2026-11-17: in the new head the radar can keep "seeing" the speaker's vibration (or the housing),
  // so after MAX_IN_A_ROW sounds it waits until the radar reports "nobody" once before playing again.
  if (!radarArmed || !motionOn || !dfReady || playing || now < quietUntil) return;
  if (++inARow >= MAX_IN_A_ROW) radarArmed = false;
  Serial.printf("[radar] motion -> next sound (%u in a row)\n", inARow);
  retriedWrap = false;
  playNext(now);
}

// Volume by button (2026-11-17): HOLD the green button 1 s = next volume step. He says a 2 s sample
// at the new volume (the last sound again, so the order isn't skipped). Steps wrap back to the quietest.
static const int VOL_STEPS[] = {6, 10, 14, 18, 22, 26};
static const int N_VOL_STEPS = sizeof(VOL_STEPS) / sizeof(VOL_STEPS[0]);
static const uint32_t HOLD_MS = 1000, PREVIEW_MS = 2000;
static uint32_t previewUntil = 0;

static void setVolume(int v, bool save) {
  VOLUME = constrain(v, 0, 30);
  dfSend(0x06, VOLUME);
  if (save) prefs.putUChar("vol", VOLUME);
  Serial.printf("[df] volume %d\n", VOLUME);
}

static void volumeStep(uint32_t now) {
  int i = 0;
  while (i < N_VOL_STEPS && VOL_STEPS[i] <= VOLUME) i++;   // next step above the current volume
  if (i >= N_VOL_STEPS) i = 0;                             // past the loudest: back to the quietest
  if (playing) { dfSend(0x16, 0); delay(30); soundFinished(now, "volume change"); }
  setVolume(VOL_STEPS[i], true); delay(30);
  dfSend(0x12, curTrack ? curTrack : 1);                   // sample at the new volume
  previewUntil = now + PREVIEW_MS;
  quietUntil = now + PREVIEW_MS + COOLDOWN_MS;             // the radar waits until the sample is over
  Serial.printf("[button] held -> volume step %d of %d\n", i + 1, N_VOL_STEPS);
}

// Green button: short press while a sound plays = stop it; short press otherwise = motion mode on/off;
// hold 1 s = louder (see volumeStep).
static void buttonPoll(uint32_t now) {
  static bool last = HIGH, stable = HIGH, heldDone = false;
  static uint32_t changed = 0, pressedAt = 0;
  if (previewUntil && now >= previewUntil) { previewUntil = 0; dfSend(0x16, 0); }   // end the sample
  bool b = digitalRead(PIN_GBUTTON);
  if (b != last) { last = b; changed = now; return; }
  if (now - changed < 40) return;                  // 40 ms debounce
  if (b == stable) {                               // no change: check for a 1 s hold
    if (b == LOW && !heldDone && now - pressedAt >= HOLD_MS) { heldDone = true; volumeStep(now); }
    return;
  }
  stable = b;
  if (b == LOW) { pressedAt = now; heldDone = false; return; }   // pressed: wait to see if it's a hold
  if (heldDone) return;                            // released after a hold: already handled
  if (previewUntil) { previewUntil = 0; dfSend(0x16, 0); return; }   // short press during a sample: stop it
  if (playing) {
    dfSend(0x16, 0);                               // stop
    Serial.println("[button] sound stopped");
    soundFinished(now, "stopped by button");       // next motion can play the next sound after the short pause
    return;
  }
  motionOn = !motionOn;
  prefs.putBool("motion", motionOn);
  digitalWrite(PIN_GLED, motionOn);
  Serial.printf("[button] motion mode %s\n", motionOn ? "ON" : "OFF");
  if (motionOn) { quietUntil = 0; radarArmed = !digitalRead(PIN_RADAR); }
}

#include "grinch_web.h"                   // phone control page on the home Wi-Fi (http://grinch.local)

static void serialCommands(uint32_t now) {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == 'p') { retriedWrap = false; playing = false; playNext(now); }
    else if (c == 'w') Serial.printf("[wifi] %s  ip %s  setup network %s\n", WiFi.status() == WL_CONNECTED ? "connected" : "not connected",
                                     WiFi.localIP().toString().c_str(), apUp ? "ON" : "off");
    else if (c == '+' || c == '-') {
      setVolume(VOLUME + (c == '+' ? 2 : -2), true);
    }
  }
}

// ---------------- drawing ----------------
static void drawEye(int cx, int cy, Gaze g, float lid, float anger, bool mirror) {
  const int H = EYE_SPRITE / 2;
  spr.fillScreen(col(SCLERA));
  float gx = g.x * GAZE_SCALE, gy = g.y * GAZE_SCALE;
  float m = hypotf(gx, gy);
  if (m > GAZE_MAX_MM) { gx *= GAZE_MAX_MM / m; gy *= GAZE_MAX_MM / m; }
  int ix = H + (int)lroundf(gx / MM_PER_PX);
  int iy = H - (int)lroundf(gy / MM_PER_PX);
  spr.fillCircle(ix, iy, IRIS_R, col(IRIS_O));
  spr.fillCircle(ix, iy, IRIS_R - 6, col(IRIS_I));
  spr.fillCircle(ix, iy, PUPIL_R, col(PUPIL));
  int gxo = mirror ? 9 : -9;
  spr.fillCircle(ix + gxo - 4, iy - 13, GLINT_R, TFT_WHITE);
  spr.fillCircle(ix + gxo + 8, iy + 2, 3, TFT_WHITE);
  if (anger > 0.001f) {                    // slanted angry lid; the inner corner faces the other eye
    float a = easeOut(anger);
    float yOut = H - OPEN_R + ANGRY_OUTER_PX * a, yIn = H - OPEN_R + ANGRY_INNER_PX * a;
    for (int x = 0; x < EYE_SPRITE; x++) {
      float u = (float)(x - (H - OPEN_R)) / (2 * OPEN_R);  // 0 at one edge of the opening, 1 at the other
      if (mirror) u = 1 - u;                               // viewer's right eye: nose is on its left
      int y = (int)lroundf(yOut + (yIn - yOut) * u);
      if (y > 0) spr.drawFastVLine(x, 0, y, col(LID));
      spr.drawFastVLine(x, max(0, y - 3), 3, col(LID_EDGE));
    }
    int lo = (int)lroundf(ANGRY_LOWER_PX * a);
    if (lo > 0) spr.fillRect(0, H + OPEN_R - lo, EYE_SPRITE, EYE_SPRITE - (H + OPEN_R - lo), col(LID));
  }
  if (lid > 0.001f) {                      // upper lid travels 70%, lower lid 30%
    int top = (int)(lid * EYE_SPRITE * 0.70f);
    int bot = (int)(lid * EYE_SPRITE * 0.30f);
    spr.fillRect(0, 0, EYE_SPRITE, top, col(LID));
    spr.fillRect(0, EYE_SPRITE - bot, EYE_SPRITE, bot, col(LID));
    spr.fillRect(0, max(0, top - 3), EYE_SPRITE, 3, col(LID_EDGE));
  }
  spr.pushSprite(cx - H, cy - H);
}

static void drawCalibration() {
  tft.fillScreen(TFT_BLACK);
  const int eyes[2][2] = {{EYE_L_X, EYE_L_Y}, {EYE_R_X, EYE_R_Y}};
  for (auto &e : eyes) {
    tft.drawCircle(e[0], e[1], 61, TFT_GREEN);   // 22 mm face opening
    tft.drawCircle(e[0], e[1], 78, TFT_DARKGREEN); // 28 mm tunnel at the screen
    tft.drawFastHLine(e[0] - 70, e[1], 140, TFT_RED);
    tft.drawFastVLine(e[0], e[1] - 70, 140, TFT_RED);
    tft.fillCircle(e[0], e[1], 4, TFT_YELLOW);
  }
  tft.drawRect(0, 0, 320, 240, TFT_BLUE);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(1);
  tft.setCursor(110, 200); tft.printf("L %d,%d", EYE_L_X, EYE_L_Y);
  tft.setCursor(110, 212); tft.printf("R %d,%d", EYE_R_X, EYE_R_Y);
  tft.setCursor(110, 224); tft.print("rot "); tft.print(SCREEN_ROTATION);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_BUTTON, INPUT_PULLUP);
  randomSeed(esp_random());
  tft.init();
  tft.setRotation(SCREEN_ROTATION);
  tft.setBrightness(BACKLIGHT);
  tft.fillScreen(TFT_BLACK);
  spr.setColorDepth(16);
  if (!spr.createSprite(EYE_SPRITE, EYE_SPRITE)) Serial.println("sprite alloc failed");
  calibration = (digitalRead(PIN_BUTTON) == LOW);
  if (calibration) drawCalibration();
  nextSaccade = millis() + 600;

  pinMode(PIN_RADAR, INPUT_PULLDOWN);
  radarLast = digitalRead(PIN_RADAR);     // someone already there at power-up doesn't count
  radarArmed = !radarLast;
  Serial1.begin(9600, SERIAL_8N1, PIN_DF_RX, PIN_DF_TX);
  prefs.begin("grinch", false);
  nextTrack = prefs.getUShort("next", 1);
  if (nextTrack < 1) nextTrack = 1;
  VOLUME = prefs.getUChar("vol", VOLUME);   // last volume picked with the button (or + / -)
  Serial.printf("[sound] next track will be %04u\n", nextTrack);
  pinMode(PIN_GBUTTON, INPUT_PULLUP);
  pinMode(PIN_GLED, OUTPUT);
  motionOn = prefs.getBool("motion", true);
  digitalWrite(PIN_GLED, motionOn);
  Serial.printf("[button] motion mode %s\n", motionOn ? "ON" : "OFF");
  webSetup();
}

void loop() {
  static bool lastBtn = true;
  bool btn = digitalRead(PIN_BUTTON);
  if (lastBtn && !btn) {                   // BOOT pressed: toggle calibration view
    calibration = !calibration;
    tft.fillScreen(TFT_BLACK);
    if (calibration) drawCalibration();
    delay(200);
  }
  lastBtn = btn;
  uint32_t now = millis();
  dfPoll(now);
  radarPoll(now);
  buttonPoll(now);
  serialCommands(now);
  webLoop(now);
  if (calibration) { delay(20); return; }

  if (now >= nextSaccade) planSaccade(now);
  float t = sacDur ? (float)(now - sacStart) / sacDur : 1;
  float k = easeOut(t);
  gazeNow.x = gazeFrom.x + (gazeTo.x - gazeFrom.x) * k;
  gazeNow.y = gazeFrom.y + (gazeTo.y - gazeFrom.y) * k;
  if (!blinking && now >= nextBlink) { planBlink(now, quickNext); quickNext = false; }
  float lid = blinkAmount(now);

  static float anger = 0;                  // 0 = calm, 1 = angry; follows "a sound is playing"
  static uint32_t last = 0;                // cap at ~60 fps
  float dtA = (float)(now - last);
  bool wantAngry = eyeMode == 1 || (eyeMode == 0 && playing);   // phone page: Auto / Angry / Calm
  anger = wantAngry ? min(1.f, anger + dtA / ANGRY_IN_MS) : max(0.f, anger - dtA / ANGRY_OUT_MS);

  drawEye(EYE_L_X, EYE_L_Y, gazeNow, lid, anger, false);
  drawEye(EYE_R_X, EYE_R_Y, gazeNow, lid, anger, true);

  uint32_t dt = millis() - last;
  if (dt < 16) delay(16 - dt);
  last = millis();
}
