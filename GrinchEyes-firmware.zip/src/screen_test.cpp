// STEP 2 - screen test. Cycles red, green, blue, white, then shows an orientation card
// for each landscape rotation (1 and 3). Note which one reads correctly with the
// yellow header pins on YOUR RIGHT - that number goes into SCREEN_ROTATION in eyes.cpp.
#include <Arduino.h>
#include "lgfx_config.h"

static LGFX tft;

static void card(int rot) {
  tft.setRotation(rot);
  tft.fillScreen(TFT_BLACK);
  tft.drawRect(0, 0, tft.width(), tft.height(), TFT_YELLOW);
  tft.setTextColor(TFT_WHITE);
  tft.setTextDatum(textdatum_t::middle_center);
  tft.setTextSize(3);
  tft.drawString("ROTATION " + String(rot), tft.width() / 2, tft.height() / 2 - 20);
  tft.setTextSize(2);
  tft.drawString("this way UP", tft.width() / 2, 20);
  tft.fillTriangle(tft.width() / 2, 40, tft.width() / 2 - 12, 60, tft.width() / 2 + 12, 60, TFT_GREEN);
  tft.drawString("Hello Grinch!", tft.width() / 2, tft.height() / 2 + 30);
  Serial.printf("showing rotation %d (%dx%d)\n", rot, tft.width(), tft.height());
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("Grinch screen test starting");
  tft.init();
  tft.setBrightness(220);
}

void loop() {
  const uint32_t cols[] = {TFT_RED, TFT_GREEN, TFT_BLUE, TFT_WHITE};
  const char *names[] = {"red", "green", "blue", "white"};
  tft.setRotation(1);
  for (int i = 0; i < 4; i++) {
    tft.fillScreen(cols[i]);
    Serial.printf("fill %s\n", names[i]);
    delay(700);
  }
  card(1); delay(4000);
  card(3); delay(4000);
}
