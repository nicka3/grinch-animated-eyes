// Grinch phone control over home Wi-Fi (2026-11-17). Included by eyes.cpp near the end, so it can use
// eyes.cpp's state and functions directly.
//
// FIRST TIME: the Grinch makes its own Wi-Fi network "Grinch-Setup" (password grinchsetup).
// Join it with your phone, a setup page opens (or browse to 192.168.4.1), pick your home Wi-Fi and
// type its password. It saves, restarts and joins your home Wi-Fi.
// AFTER THAT: on the home Wi-Fi, open  http://grinch.local  (or the IP printed in the Serial Monitor).
// If it can't join the home Wi-Fi within 20 s, "Grinch-Setup" comes back so you can fix it.
// To forget the saved Wi-Fi: hold the green button while plugging in the USB cable.
#pragma once
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <ESPmDNS.h>

static const char *AP_NAME = "Grinch-Setup", *AP_PASS = "grinchsetup", *HOSTNAME = "grinch";
static WebServer web(80);
static DNSServer dns;
static bool apUp = false, staReported = false;
static uint32_t wifiStart = 0;
static uint8_t eyeMode = 0;                 // 0 = auto (angry while speaking), 1 = always angry, 2 = always calm
static uint8_t backlight = BACKLIGHT;

static void startSetupAP() {
  if (apUp) return;
  WiFi.mode(WiFi.getMode() == WIFI_STA ? WIFI_AP_STA : WIFI_AP);
  WiFi.softAP(AP_NAME, AP_PASS);
  dns.start(53, "*", WiFi.softAPIP());      // any web address -> the setup page
  apUp = true;
  Serial.printf("[wifi] setup network \"%s\" (password %s) -> http://%s\n", AP_NAME, AP_PASS, WiFi.softAPIP().toString().c_str());
}

static void stopSetupAP() {
  if (!apUp) return;
  dns.stop(); WiFi.softAPdisconnect(true); WiFi.mode(WIFI_STA); apUp = false;
  Serial.println("[wifi] setup network off");
}

// ---------------- pages ----------------
static const char PAGE_CONTROL[] PROGMEM = R"HTML(<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Grinch</title><style>
:root{--g:#5a9e2a;--gd:#2f5e12;--bg:#11170d;--card:#1c2616;--t:#e8f3dc;--mut:#9db58a;--red:#c8302c}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--t);font:16px system-ui,-apple-system,sans-serif}
main{max-width:520px;margin:0 auto;padding:14px 16px 40px}h1{font-size:22px;margin:4px 0 12px;color:#9fd36a}
.card{background:var(--card);border-radius:14px;padding:14px;margin:0 0 12px}.card h2{font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--mut);margin:0 0 10px}
.row{display:flex;gap:8px;flex-wrap:wrap}button{flex:1;min-width:64px;border:0;border-radius:10px;padding:13px 8px;font:600 16px system-ui;background:#2b3a22;color:var(--t)}
button.on{background:var(--g);color:#0d1408}button.big{background:var(--g);color:#0d1408}button.stop{background:var(--red);color:#fff}
.grid{display:grid;grid-template-columns:repeat(6,1fr);gap:6px}.grid button{min-width:0;padding:11px 0}
.stat{display:grid;grid-template-columns:auto 1fr;gap:4px 12px;font-size:15px}.stat span:nth-child(odd){color:var(--mut)}
input[type=range]{width:100%;accent-color:var(--g)}.val{float:right;color:#9fd36a;font-weight:700}a{color:var(--mut)}
.dot{display:inline-block;width:10px;height:10px;border-radius:50%;background:#555;margin-right:6px}.dot.yes{background:#9fd36a}
</style></head><body><main><h1>The Grinch</h1>
<div class="card"><h2>Status</h2><div class="stat">
<span>Radar</span><b id="radar"><span class="dot"></span>…</b><span>Sound</span><b id="snd">…</b>
<span>Next</span><b id="next">…</b><span>Wi-Fi</span><b id="rssi">…</b></div></div>
<div class="card"><h2>Sound</h2><div class="row"><button class="big" onclick="cmd('next')">▶ Play next</button>
<button class="stop" onclick="cmd('stop')">■ Stop</button></div>
<p style="margin:12px 0 6px;color:var(--mut);font-size:14px">Play a sound</p><div class="grid" id="tracks"></div></div>
<div class="card"><h2>Volume <span class="val" id="vv"></span></h2><input type="range" id="vol" min="0" max="30"
oninput="vv.textContent=this.value" onchange="cmd('vol','v='+this.value)"><p style="margin:6px 0 0;color:var(--mut);font-size:13px">Above 26 starts to distort.</p></div>
<div class="card"><h2>Motion sensor</h2><div class="row"><button id="m1" onclick="cmd('motion','on=1')">On</button><button id="m0" onclick="cmd('motion','on=0')">Off</button></div></div>
<div class="card"><h2>Eyes</h2><div class="row"><button id="e0" onclick="cmd('eyes','m=0')">Auto</button><button id="e1" onclick="cmd('eyes','m=1')">Angry</button><button id="e2" onclick="cmd('eyes','m=2')">Calm</button></div>
<p style="margin:12px 0 6px;color:var(--mut);font-size:14px">Look (as seen from the front)</p>
<div class="row"><button onclick="cmd('look','d=l')">◀</button><button onclick="cmd('look','d=c')">●</button><button onclick="cmd('look','d=r')">▶</button><button onclick="cmd('blink')">Blink</button></div>
<p style="margin:12px 0 6px;color:var(--mut);font-size:14px">Screen brightness <span class="val" id="bv"></span></p>
<input type="range" id="bri" min="20" max="255" oninput="bv.textContent=this.value" onchange="cmd('bright','v='+this.value)"></div>
<p style="text-align:center;font-size:13px"><a href="/wifi">Change Wi-Fi</a></p></main>
<script>
let n=0,busy=0;const $=id=>document.getElementById(id);
function cmd(c,a){fetch('/api/cmd?c='+c+(a?'&'+a:'')).then(r=>r.json()).then(show)}
function tracks(t){if(t==n)return;n=t;let h='';for(let i=1;i<=(t||12);i++)h+='<button onclick="cmd(\'play\',\'n='+i+'\')">'+i+'</button>';$('tracks').innerHTML=h}
function show(s){tracks(s.count);$('radar').innerHTML='<span class="dot'+(s.radar?' yes':'')+'"></span>'+(s.radar?'sees someone':'nobody');
$('snd').textContent=s.playing?'playing '+s.track:(s.motion?'quiet':'quiet (motion off)');$('next').textContent=s.next+' of '+(s.count||'?');
$('rssi').textContent=s.rssi+' dBm';if(document.activeElement!=$('vol')){$('vol').value=s.vol;$('vv').textContent=s.vol}
if(document.activeElement!=$('bri')){$('bri').value=s.bright;$('bv').textContent=s.bright}
$('m1').className=s.motion?'on':'';$('m0').className=s.motion?'':'on';for(let i=0;i<3;i++)$('e'+i).className=s.eyes==i?'on':''}
function poll(){fetch('/api/status').then(r=>r.json()).then(show).catch(()=>{}).finally(()=>setTimeout(poll,1000))}poll();
</script></body></html>)HTML";

static String htmlEscape(const String &s) {
  String o; for (char c : s) { if (c == '<') o += "&lt;"; else if (c == '>') o += "&gt;"; else if (c == '"') o += "&quot;"; else if (c == '&') o += "&amp;"; else o += c; } return o;
}

static void pageWifi() {
  int n = WiFi.scanNetworks();               // ~2 s; the eyes pause briefly
  String opts;
  for (int i = 0; i < n; i++) {
    String s = WiFi.SSID(i); if (!s.length() || opts.indexOf("\"" + htmlEscape(s) + "\"") >= 0) continue;
    opts += "<option value=\"" + htmlEscape(s) + "\">" + htmlEscape(s) + " (" + String(WiFi.RSSI(i)) + " dBm)</option>";
  }
  WiFi.scanDelete();
  String h = F("<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Grinch Wi-Fi</title>"
    "<style>body{margin:0;background:#11170d;color:#e8f3dc;font:16px system-ui,sans-serif}main{max-width:460px;margin:0 auto;padding:18px 16px}"
    "h1{color:#9fd36a;font-size:22px}label{display:block;margin:14px 0 6px;color:#9db58a}select,input{width:100%;font:16px system-ui;padding:12px;border-radius:10px;border:0;background:#1c2616;color:#e8f3dc}"
    "button{margin-top:18px;width:100%;padding:14px;border:0;border-radius:10px;background:#5a9e2a;color:#0d1408;font:700 17px system-ui}p{color:#9db58a;font-size:14px}</style></head><body><main>"
    "<h1>Grinch Wi-Fi</h1><p>Pick your home Wi-Fi (2.4 GHz). The Grinch saves it, restarts, and then lives at <b>http://grinch.local</b>.</p>"
    "<form method='post' action='/wifi/save'><label>Network</label><select name='s'>");
  h += opts;
  h += F("</select><label>Or type the name</label><input name='s2' autocapitalize='none' autocorrect='off' placeholder='only if it is not in the list'>"
    "<label>Password</label><input name='p' type='password'><button>Save and connect</button></form>"
    "<form method='post' action='/wifi/forget'><button style='background:#3a2620;color:#f0c0b8'>Forget saved Wi-Fi</button></form></main></body></html>");
  web.send(200, "text/html", h);
}

static void sendStatus() {
  char b[220];
  snprintf(b, sizeof b, "{\"playing\":%d,\"track\":%u,\"next\":%u,\"count\":%u,\"vol\":%d,\"motion\":%d,\"radar\":%d,\"eyes\":%u,\"bright\":%u,\"rssi\":%d}",
           playing, curTrack, nextTrack, trackCount, VOLUME, motionOn, (int)digitalRead(PIN_RADAR), eyeMode, backlight, (int)WiFi.RSSI());
  web.send(200, "application/json", b);
}

static void apiCmd() {
  uint32_t now = millis();
  String c = web.arg("c");
  Serial.printf("[web] %s\n", c.c_str());
  if (c == "next" && dfReady) { retriedWrap = false; playing = false; playNext(now); }
  else if (c == "play" && dfReady) {
    int n = web.arg("n").toInt();
    if (n >= 1 && (!trackCount || n <= trackCount)) { nextTrack = n; retriedWrap = false; playing = false; playNext(now); }
  }
  else if (c == "stop") { previewUntil = 0; dfSend(0x16, 0); soundFinished(now, "stopped from phone"); }
  else if (c == "vol") setVolume(web.arg("v").toInt(), true);
  else if (c == "motion") {
    motionOn = web.arg("on") == "1"; prefs.putBool("motion", motionOn); digitalWrite(PIN_GLED, motionOn);
    if (motionOn) { quietUntil = 0; radarArmed = !digitalRead(PIN_RADAR); }
  }
  else if (c == "eyes") eyeMode = constrain(web.arg("m").toInt(), 0, 2);
  else if (c == "look") {
    String d = web.arg("d");
    gazeFrom = gazeNow; gazeTo = {d == "l" ? -2.0f : d == "r" ? 2.0f : 0.f, 0}; sacStart = now; sacDur = 60;
    nextSaccade = now + 4000;                // hold the look for 4 s, then go back to wandering
  }
  else if (c == "blink") { if (!blinking) planBlink(now, true); }
  else if (c == "bright") { backlight = constrain(web.arg("v").toInt(), 20, 255); tft.setBrightness(backlight); prefs.putUChar("bright", backlight); }
  sendStatus();
}

static void webSetup() {
  if (digitalRead(PIN_GBUTTON) == LOW) {     // green button held at power-up: forget Wi-Fi
    prefs.remove("wssid"); prefs.remove("wpass"); Serial.println("[wifi] saved Wi-Fi forgotten (green button held)");
  }
  backlight = prefs.getUChar("bright", BACKLIGHT); tft.setBrightness(backlight);
  String ssid = prefs.getString("wssid", ""), pass = prefs.getString("wpass", "");
  WiFi.persistent(false);
  WiFi.setHostname(HOSTNAME);
  if (ssid.length()) {
    WiFi.mode(WIFI_STA); WiFi.setAutoReconnect(true); WiFi.begin(ssid.c_str(), pass.c_str());
    Serial.printf("[wifi] joining \"%s\"...\n", ssid.c_str());
  } else {
    Serial.println("[wifi] no home Wi-Fi saved yet");
    startSetupAP();
  }
  wifiStart = millis();

  web.on("/", HTTP_GET, []() {
    if (apUp && WiFi.status() != WL_CONNECTED) { pageWifi(); return; }   // setup mode: go straight to Wi-Fi setup
    web.send_P(200, "text/html", PAGE_CONTROL);
  });
  web.on("/control", HTTP_GET, []() { web.send_P(200, "text/html", PAGE_CONTROL); });
  web.on("/wifi", HTTP_GET, pageWifi);
  web.on("/wifi/save", HTTP_POST, []() {
    String s = web.arg("s2"); s.trim(); if (!s.length()) s = web.arg("s");
    if (!s.length()) { web.send(400, "text/plain", "No network chosen"); return; }
    prefs.putString("wssid", s); prefs.putString("wpass", web.arg("p"));
    web.send(200, "text/html", "<meta name='viewport' content='width=device-width'><body style='background:#11170d;color:#e8f3dc;font:18px system-ui;padding:20px'>"
             "Saved. The Grinch is restarting and joining <b>" + htmlEscape(s) + "</b>.<br><br>Switch your phone back to your home Wi-Fi and open <b>http://grinch.local</b> in about 20 seconds.</body>");
    Serial.printf("[wifi] saved \"%s\", restarting\n", s.c_str());
    delay(800); ESP.restart();
  });
  web.on("/wifi/forget", HTTP_POST, []() {
    prefs.remove("wssid"); prefs.remove("wpass");
    web.send(200, "text/plain", "Forgotten. Restarting into setup mode (Wi-Fi \"Grinch-Setup\").");
    delay(800); ESP.restart();
  });
  web.on("/api/status", HTTP_GET, sendStatus);
  web.on("/api/cmd", HTTP_GET, apiCmd);
  web.onNotFound([]() {                      // phones probe odd URLs to detect a sign-in page
    if (apUp) { web.sendHeader("Location", "http://" + WiFi.softAPIP().toString() + "/", true); web.send(302, "text/plain", ""); }
    else web.send(404, "text/plain", "Not found");
  });
  web.begin();
}

static void webLoop(uint32_t now) {
  if (apUp) dns.processNextRequest();
  web.handleClient();
  bool up = WiFi.status() == WL_CONNECTED;
  if (up && !staReported) {
    staReported = true;
    if (MDNS.begin(HOSTNAME)) MDNS.addService("http", "tcp", 80);
    Serial.printf("[wifi] connected to \"%s\": http://%s.local  or  http://%s\n", WiFi.SSID().c_str(), HOSTNAME, WiFi.localIP().toString().c_str());
    if (apUp) stopSetupAP();
  }
  if (!up && staReported) { staReported = false; wifiStart = now; Serial.println("[wifi] lost connection, retrying"); }
  if (!up && !apUp && now - wifiStart > 20000) startSetupAP();   // couldn't join: offer setup again
}
