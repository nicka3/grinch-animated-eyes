// Screen wiring + driver setup shared by both programs.
// 2.8" ILI9341 SPI module  ->  ESP32-S3-DevKitC-1
//   VCC->3V3  GND->G  CS->10  RESET->8  DC->9  SDI(MOSI)->11  SCK->12  LED->7  SDO(MISO)->13
#pragma once
#define LGFX_USE_V1
#include <LovyanGFX.hpp>

static const int PIN_SCLK = 12, PIN_MOSI = 11, PIN_MISO = 13, PIN_DC = 9, PIN_CS = 10, PIN_RST = 8, PIN_BL = 7;
static const bool PANEL_INVERT = false;   // set true if colours look like a photo negative

class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_ILI9341 _panel;
  lgfx::Bus_SPI _bus;
  lgfx::Light_PWM _light;
 public:
  LGFX() {
    { auto c = _bus.config();
      c.spi_host = SPI2_HOST; c.spi_mode = 0;
      c.freq_write = 40000000; c.freq_read = 16000000;
      c.spi_3wire = false; c.use_lock = true; c.dma_channel = SPI_DMA_CH_AUTO;
      c.pin_sclk = PIN_SCLK; c.pin_mosi = PIN_MOSI; c.pin_miso = PIN_MISO; c.pin_dc = PIN_DC;
      _bus.config(c); _panel.setBus(&_bus); }
    { auto c = _panel.config();
      c.pin_cs = PIN_CS; c.pin_rst = PIN_RST; c.pin_busy = -1;
      c.panel_width = 240; c.panel_height = 320;
      c.offset_x = 0; c.offset_y = 0; c.offset_rotation = 0;
      c.readable = false; c.invert = PANEL_INVERT; c.rgb_order = false;
      c.dlen_16bit = false; c.bus_shared = false;
      _panel.config(c); }
    { auto c = _light.config();
      c.pin_bl = PIN_BL; c.invert = false; c.freq = 44100; c.pwm_channel = 7;
      _light.config(c); _panel.setLight(&_light); }
    setPanel(&_panel);
  }
};
